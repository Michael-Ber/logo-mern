import React from 'react';
import "./error.scss";

export const Error = () => {
  return (
    <div className='error'>Что-то пошло не так...</div>
  )
}
