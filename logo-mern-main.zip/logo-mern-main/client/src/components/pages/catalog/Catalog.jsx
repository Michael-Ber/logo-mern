import React from 'react'

export const Catalog = () => {
  return (
    <div>Catalog</div>
  )
}
