import React from 'react'

export const Test = () => {
  return (
    <p style={{fontSize: '24px', textAlign: 'center'}}>Это демонстрационный сайт</p>
  )
}
