<?php
file_put_contents('db.json', $_POST['items']);